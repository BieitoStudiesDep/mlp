
- Cambia los nombres de los dos notebooks, poniendo tu primer apellido y nombre al principio.
- El primer notebook (_P1) consiste en 8 supuestos para hacer un breve análisis de cada uno en el apartado de "Respuestas".
- A lo largo del segundo notebook (_P2) aparecen 5 preguntas numeradas; respóndelas debajo de cada una.
- Para entregar, comprime los dos notebooks en un archivo .zip con el siguiente formato de nombre: "Apellido1Nombre_SAA_Parcial.zip" y súbelo a la sección correspondiente.