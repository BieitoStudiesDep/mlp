# SAA01_Tarea

## **Índice**

[Apartado 1 Teorema de Bayes](#apartado-1)

1. [enunciado](#aplica-el-teorema-de-bayes-a-un-problema-de-diagnóstico-de-cáncer)
2. [Documentación](#documentación)
3. [Resolución](#resolución)
4. [Calculadora de Bayes](calculadora-de-bayes)

[Apartado 2 Teorema de Bayes](#apartado-2)

1. [Resolución](#resolución-apartado-2)

[Apartado 3 Teorema de Bayes](#apartado-3)

1. [Reflexion IA Fuerte](#reflexión-ia-fuerte)

## Apartado 1

### **Aplica el Teorema de Bayes a un problema de diagnóstico de cáncer.**

1. En un determinado grupo poblacional, la probabilidad de tener cáncer es del 0,02%. Por otro lado, existe una prueba para detectarlo que no siempre es precisa. En caso de tener cáncer, arroja un resultado positivo el 85% de las veces, y en caso de no tener cáncer, arroja un resultado negativo el 95% de las veces.
2. Calcular la probabilidad de que se tenga cáncer si la prueba da positiva.
3. Entra en la web de cálculo del Teorema de Bayes para comprobar si tus cálculos son correcto
4. Escribe los razonamientos de tus cálculos y añade captura de pantalla del uso de la [calculadora de Bayes](https://www.ugr.es/~jsalinas/bayes.htm).

### Documentación

#### Teorema de Bayes

Principio fundamental en la teoría de probabilidad que permite actualizar nuestras creencias sobre un evento en función de nueva evidencia.

**_Fórmula_**

$$P(A|B) = \frac{P(B|A) \cdot P(A)}{P(B)}$$

**_Términos en la Fórmula_**

- $P(A)$ y $P(B)$ son las probabilidades _a priori_ de dichos eventos. Las probabilidades de que dichos eventos sucedan sin estar condicionados por ningún otro evento.
- $P(A|B)$ es la probabilidad condicional o _a posteriori_ de la hipótesis $A$ dado el evento $B$, o sea: la probabilidad de que A se dé dado que B se ha dado..

#### Ley de Probabilidad Total

Esta fórmula se utiliza para calcular la probabilidad de un evento $B$ mediante la consideración de dos escenarios: cuando ocurre un evento

**_Fórmula_**

$$P(B) = P(B|A) \cdot P(A) + P(B|\neg A) \cdot P(\neg A)$$

**_Términos en la Fórmula_**

- **(B)** Probabilidad de que ocurra el evento $B$, sin importar si $A$ ha ocurrido o no.

- **P(B|A)** Probabilidad condicional de que ocurra $B$ dado que ya ha ocurrido $A$. Es la probabilidad de $B$ en el escenario en el que $A$ es conocido o ha ocurrido.

- **P(A):** Probabilidad de que ocurra el evento $A$, sin tener en cuenta si $B$ ha ocurrido o no.

- **P(B|¬A):** Probabilidad condicional de que ocurra $B$ dado que no ha ocurrido $A$. Es la probabilidad de $B$ en el escenario en el que sabemos que $A$ no ha ocurrido.

- **P(¬A):** Probabilidad de que no ocurra el evento $A$, es decir, la probabilidad de la no ocurrencia de $A$ sin tener en cuenta si $B$ ha ocurrido o no.

### Resolución

#### **Tratamos los datos del enunciado**

> la probabilidad de tener cáncer es del 0,02%.

$P(A)$

- valor ➡ (0,02% ➡ 0,0002).
- concepto ➡ Probabilidad de `tener cáncer`

$P(\neg A)$

- valor ➡ 0,98% ➡(1 - 0,0002) ➡ 0,9998
- concepto ➡ Probabilidad de `no tener cáncer`

> En caso de tener cáncer, arroja un resultado positivo el 85% de las veces

$P(B|A)$

- valor ➡ (85% o 0,85).
- concepto ➡ Probabilidad de tener un resultado positivo en la prueba dado que se tiene cáncer

> en caso de no tener cáncer, arroja un resultado negativo el 95% de las veces.

$P(B| A)$

- valor ➡ (85% o 0,85)
- concepto ➡ `cancer` resultado `positivo`.

$P(B|\neg A)$

- valor ➡ (5% o 0,05)
- concepto ➡`no cancer` resultado `falso positivo`.

Como conocemos dos estenarios

Probabilidad de obtener un resultado positivo en la prueba cuando

1. $P(B)$ : tiene cancer
2. $P(B|\neg A)$ : no se tiene cáncer

#### **Aplicamos `ley de probabilidad total` para hayar $P(B)$**

Como tenemos dos estenarios podemos aplicar `ley de probabilidad total`.

$$P(B) = P(B|A) \cdot P(A) + P(B|\neg A) \cdot P(\neg A)$$

$P(B)=P(B∣A) \cdot P(A)+P(B∣¬A) \cdot P(¬A)$

$P(B)=0,85 \cdot 0,0002+0,05 \cdot (1−0,0002)$

$P(B)≈0,00017+0,0499$

$P(B)≈0,05007$

`Resultado P(B) ≈ 0,05007`

#### **Aplicamos `Teorema de Bayes` para hayar $P(B)$**

$P(A∣B)=\frac{P(B)P(B∣A)}{P(A)}$

$P(A∣B)=\frac{0,85⋅0,0002​}{0,05007}$

$P(A∣B)≈\frac{0,00017}{0,05007}$

$P(A∣B)≈0,0034$

`Resultado P(A∣B) ≈0,0034`

### Calculadora de bayes

![Calculadora de bayes](./img-calculadora-bayes.png)

## Apartado 2

### Aplica la clasificacíon de KNN

Dada la distribución de datos de la imagen, aplica, de forma gráfica, la clasificación KNN con un K=3 para los siguientes puntos:

- (2.5, 7)
- (5.5, 4.5).

![imagen KNN](./img-apartado02.png)

### Resolución Apartado 2

Situamos los puntos
![imagen KNN](./img-apartado02-points.png)

`El punto 1 (2.5, 7) ➡ seria verde`
`El punto 1 (5.5, 4.5) ➡ seria rojo`

Analiza cuál tendría que ser el valor de K mínimo para que hubiese empate entre ambas clases para cualquiera de los dos puntos.

![imagen KNN](./img-apartado02-eq.png)

aproximadamente sabemos que en `P1` (2.5, 7)

- en k6 5🟩 1 🟥
- en k12 8🟩 4 🟥

aproximadamente sabemos que en `P2` (5.5, 4.5)

- en k7 1🟩 6 🟥
- en k14 6🟩 8 🟥

| k   | P01      | P02      |
| --- | -------- | -------- |
| 1   | 1🟩 0🟥  | 0🟩 1🟥  |
| 2   | 2🟩 0🟥  | 0🟩 2🟥  |
| 3   | 3🟩 0🟥  | 0🟩 3🟥  |
| 4   | 3🟩 0🟥  | 0🟩 3🟥  |
| 5   | 4🟩 0🟥  | 0🟩 4🟥  |
| 6   | 5🟩 1🟥  | 0🟩 5🟥  |
| 7   | 6🟩 1🟥  | 1🟩 6🟥  |
| 8   | 6🟩 2🟥  | 1🟩 7🟥  |
| 9   | 7🟩 2🟥  | 2🟩 7🟥  |
| 10  | 7🟩 3🟥  | 3🟩 7🟥  |
| 11  | 7🟩 4🟥  | 4🟩 7🟥  |
| 12  | 8🟩 4 🟥 | 5🟩 7🟥  |
| 13  | 8🟩 5 🟥 | 6🟩 7🟥  |
| 14  | 8🟩 6 🟥 | 6🟩 8 🟥 |
| 15  | 8🟩 7 🟥 | 7🟩 8 🟥 |
| 16  | 8🟩 8 🟥 | 8🟩 8 🟥 |

Sería k=16 cogiendo todos los puntos

## Apartado 3

### Reflexión IA Fuerte

Apartado 3: Reflexión sobre la factibilidad de una inteligencia artificial fuerte.
En función de lo visto en la unidad de trabajo, piensa en el concepto de IA Fuerte.
¿Crees que realmente sería posible llegar a desarrollar una IA general que supere la inteligencia humana?

### Respuesta Apartado03

Voy a plantear en primer lugar que la idea de una de una IA fuerte es una utopía.
por dos razones
1º no conocemos ni cognitivamente ni físicamente el alcance de la mente humana con lo cual estamos comparando una idea/percepción/imagen … de lo que es el proceso cognitivo-inteligencia … humanos aún no hemos desarrollado instrumentos/ herramientas para medir con exactitud/ precisión este tipo de magnitudes .
2º Una máquina , entorno computacional. no deja de ser una caja tonta la cual tiene a través de tu implementar unos inputs de una manera extremadamente rápida ofrece unos outputs con un margen de error que según una calibración tiende a cero. este proceso de cálculo si lo sometes a un proceso multihilo o secuencial donde unifiques varios procesos y establezcas relaciones en las cuales los outputs de unos sean los inputs de otros crece exponencialmente.
Es cierto que si establecemos un sistema de nodos donde entrenamos las salidas válidas para cada concepto validando las y invalidando las. Al final diseñamos una red en la cual para un concepto tenemos múltiples salidas y simulamos un pensamiento lateral e incluso podemos llegar a ver ciertas relaciones que a priori no son naturales , pero que las máquinas nos pueden llegar a mostrar.
Pero considero que si es verdad que es un gran avance que las máquinas puedan pasar de una respuesta más secuencial a una más “red-conceptual “ pero hay demasiadas percepciones y variables como el entorno, el estado de ánimo , momento vital … que muchas veces de manera global no podemos definir con datos con lo cual no puedes llegar a plasmarlas en una máquina.
Si prepararlas para un entorno y unas acciones concretas, y alcanzar un objetivo delimitando la muestra de datos, pero al final tienes que realizar un filtrado, por que hay determinadas cosas que no expresamos en datos o que no son relevantes para el objetivo o para el algoritmo.
Al final la IA es una herramienta que hace un desarrollador con una intencionalidad y un objetivo. Muchas veces este último es movido para monetizar las acciones de la misma. Al final en la mayoría de los casos no se intenta replicar un modelo humano en sí mismo, se intenta gestionar un volumen de datos masivo y llegar a una respuesta humanizada , la cual puede ser entendida y tratada por un humano de una forma cómoda y sencilla, pero siempre marcada por la intención o el objetivo para que fue creada la tecnología, los intereses son diversos, prestigio , monetizar, ego , vanguardia … pero al fin y al cabo lleguen donde lleguen las IA los humanos utilizamos el conocimiento y las acciones que proporciones para alcanzar un fin.
Por poner un símil es como el autotune permite que cualquier persona sin capacidades vocales pueda llegar a realizar una canción con lo cual permite a gente sin talento a priori llegar a la industria y a gente con talento alcanzar antes ese “pico” y poder emplear su energía en otros factores que potencien sus habilidades.
En mi opinión la IA es un poco lo mismo, permite llegar a un conocimiento a una acción a un objetivo, a una conclusión, de manera más rápida y más eficaz , pero una vez que el conocimiento o esa acción ya no es el reto empresarial se abre otro y otro y así sucesivamente. y al final no deja de ser una competencia los unos con los otros en la cual nos estamos auto renovando y adaptando para intentar beneficiarnos a nosotros mismo.
Ahora mismo no veo definido un punto donde la IA por muy perfeccionada que este termine con ese flujo.
Desde que nacemos es una rueda constante con el tiempo por aprender, optimizar y generar habilidades y destrezas que nos hagan especiales y nos diferencien frente a los demás.
La IA va a complicar esta parte, va a dar acceso a gente a priori con menos talento pero que dedica más tiempo y más esfuerzo a llegar al mismo punto pero siempre el talento te dará cortos matices .
Y lamentablemente no todas las personalidades están preparadas para convivir con la IA y si que pienso que vamos a evolucionar en el sentido de que aquellas personas que no toleren una curva de aprendizaje continua y vitalicia que no les permita adaptarse y renovarse, caerán en vicios , depresiones , angustia …
El conocimiento no es un reto en sí mismo, por lo tanto con saber no es suficiente, hoy en día el reto es gestionar un volumen de información necesario para avanzar en tu tarea o tus objetivos, y una vez llegues avanzar en el siguiente punto.
